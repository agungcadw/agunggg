<?= $this->include('templates/header'); ?>
    <div class="container">
        <h1 class="in-css">Hello World</h1>
    </div>
<?= $this->include('templates/footer'); ?>

<style>
    .container {
        padding: 2em;
    }
    h1.in-css {
        font-family: arial, sans, serif, halvetica;
    }
</style>