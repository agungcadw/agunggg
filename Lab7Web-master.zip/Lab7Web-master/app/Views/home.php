<?= $this->extend('layout/main') ?>
<?= $this->section('content') ?>

    <div class="content-container">
        <h1><?= $title; ?></h1>
        <br>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Illum a, eum officia sunt quibusdam repellat unde, exercitationem at, alias soluta adipisci nulla? Ab sit voluptatibus et. Tenetur in alias eum accusantium mollitia possimus laborum. Asperiores beatae autem facere nam reprehenderit dolorem eius veniam fugit atque qui? Nisi autem impedit cupiditate et possimus minus vitae quibusdam omnis nobis necessitatibus dignissimos dolore similique laboriosam illo veritatis magni, dolorem expedita doloremque repudiandae quidem animi sunt quis consectetur! Et officia in ratione cum modi nobis dolor, ad neque tempore temporibus ducimus, asperiores molestiae. Sequi corrupti suscipit placeat est veritatis, similique culpa. Obcaecati, numquam natus!</p>
    </div>

<?= $this->endSection() ?>