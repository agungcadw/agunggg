<?= $this->include('templates/header'); ?>

<?= $this->renderSection('content') ?>

<?= $this->include('templates/footer'); ?>