Praktikum 1 (Pertemuan 2)

1. Codeigneiter First Look
   ![Screenshot 2025-04-22 070954](https://github.com/user-attachments/assets/a72b083f-afc1-4359-8432-69c47c10c8b7)
   
2. Mengubah Environment Variable:
   Ketika terjadi error (Production):
   ![image](https://github.com/user-attachments/assets/f1079c09-8632-42de-8f25-daaa0534a6a2)
   Ketika terjadi error (Development):
   ![image](https://github.com/user-attachments/assets/4301cbcb-87ce-4a4e-8409-74f81ee2fea8)

3. Membuat Page controller dan method about
   ![Screenshot 2025-04-22 071056](https://github.com/user-attachments/assets/a901fb1e-447e-46d4-802d-20480fe26815)

4. Membuat View about.php dan mengubah routes /about agar me-return view about.php
   ![Screenshot 2025-04-22 071451](https://github.com/user-attachments/assets/f188b6ac-9c56-4bd1-8377-2d91e8fcf5ae)

5. Menambahkan template header dan footer
   ![Screenshot 2025-04-22 072108](https://github.com/user-attachments/assets/34c16c5e-5517-4890-825a-8e3bada502cf)

6. Memberi style dengan menambahkan style.css pada public directory
   ![Screenshot 2025-04-22 074003](https://github.com/user-attachments/assets/7c5b0fb2-b50b-4bc5-87d9-821b92c2f41e)

7. Menyelesaikan tampilan halaman lain
   ![Screenshot 2025-04-23 114814](https://github.com/user-attachments/assets/63e106cc-f5d4-406f-9ba4-d9c957c6d551)
   ![Screenshot 2025-04-23 114821](https://github.com/user-attachments/assets/fba135eb-b493-48d0-ab20-6bf98dd57594)
   ![Screenshot 2025-04-23 114827](https://github.com/user-attachments/assets/b37c1de9-38cb-4554-b282-b295cc7bf36f)
   ![Screenshot 2025-04-23 114833](https://github.com/user-attachments/assets/4186a719-6ce5-43e6-bd85-4fd6122329a5)


Praktikum 2 (Pertemuan 3)

1. Menambahkan admin page untuk mengelola artikel
   ![image](https://github.com/user-attachments/assets/f166cae7-8bd9-4677-877c-276c76b90e30)

2. Membuat form tambah artikel
   ![image](https://github.com/user-attachments/assets/46d81fa2-eeab-4f07-a585-18058315585a)

3. Membuat form edit artikel dan route ke edit view ketika button ubah di click
   ![image](https://github.com/user-attachments/assets/70951976-0fa0-46b6-acdd-c75df2c20d4e)

4. Membuat route delete artikel, untuk mengapus artikel tertentu berdasarkan id yang dikirim dengan cara meng-click button hapus
   ![image](https://github.com/user-attachments/assets/03ddfa80-d466-4506-ae53-013eedc8dc4d)


Praktikum 3 (Pertemuan 4)

1. Menambahkan widget artikel terkini dan memperbarui tampilan homepage
   ![image](https://github.com/user-attachments/assets/108fb406-41d3-4f22-a7b4-ac51005a9a74)

2. Menggunakan View Cell memungkinkan kita untuk memisahkan tampilan menjadi beberapa components


Praktikum 4 (Pertemuan 5)

1. Mmebuat login page, mengaplikasikan filter untuk otentikasi dan session
   ![image](https://github.com/user-attachments/assets/c71e4c7b-537d-4aa3-8e9f-a03c0fdf9f3e)


Praktikum 5 (Pertemuan 6)

1. Membuat pagination pada list artikel
   ![Screenshot 2025-04-28 204059](https://github.com/user-attachments/assets/d29cb15a-7b67-47ab-a6c1-f3d6257fb18a)
   ![image](https://github.com/user-attachments/assets/02f04f7f-eb87-4c6a-bc43-f9551bba80f3)


2. Menambahkan kolom pencarian untuk memfilter artikel yang akan ditampilkan berdasarkan kesamaan judul yang di input pada kolom pencarian
   ![image](https://github.com/user-attachments/assets/c646038a-74bc-4032-8e9b-12bdac5ec290)
   ![image](https://github.com/user-attachments/assets/956898df-4cad-49eb-881d-e9cf41455d4e)

Praktikum 6 (Pertemuan 7)

1. Membuat input type file untuk input gambar artikel
   ![image](https://github.com/user-attachments/assets/b8ac9b4b-ce2f-4c1e-bc96-277893b2d42e)

2. Nama gambar yang diupload akan disimpan didalam database
   ![image](https://github.com/user-attachments/assets/c8c4891e-4b5b-492c-b0ad-d6f59c1124ad)






